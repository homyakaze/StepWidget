package com.example.steps

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast

// Открывается один раз: просит разрешение, запускает счётчик и закрывается.
class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION) == PackageManager.PERMISSION_GRANTED) {
            startAndFinish()
        } else {
            requestPermissions(arrayOf(Manifest.permission.ACTIVITY_RECOGNITION), 1)
        }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        if (res.isNotEmpty() && res[0] == PackageManager.PERMISSION_GRANTED) startAndFinish() else finish()
    }

    private fun startAndFinish() {
        startForegroundService(Intent(this, StepService::class.java))
        Toast.makeText(this, "Готово. Добавьте виджет «Шаги» на экран", Toast.LENGTH_LONG).show()
        finish()
    }
}
