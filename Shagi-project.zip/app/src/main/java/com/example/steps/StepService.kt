package com.example.steps

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.IBinder

class StepService : Service(), SensorEventListener {

    private lateinit var nm: NotificationManager

    override fun onCreate() {
        super.onCreate()
        nm = getSystemService(NotificationManager::class.java)
        nm.deleteNotificationChannel("steps") // старый канал (был скрытый)
        val ch = NotificationChannel("steps2", "Шагомер", NotificationManager.IMPORTANCE_LOW)
        ch.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        ch.setShowBadge(false)
        nm.createNotificationChannel(ch)

        startForeground(1, buildNotification())

        val sm = getSystemService(SensorManager::class.java)
        sm.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)?.let {
            sm.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL)
        }
    }

    private fun buildNotification(): Notification {
        val steps = "%,d".format(StepStore.today(this)).replace(',', ' ')
        return Notification.Builder(this, "steps2")
            .setSmallIcon(R.drawable.ic_step)
            .setContentTitle("\uD83D\uDC63 $steps")
            .setContentText("шагов сегодня")
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setOngoing(true)
            .build()
    }

    override fun onSensorChanged(e: SensorEvent) {
        StepStore.onRaw(this, e.values[0].toLong())
        StepWidget.refresh(this)
        nm.notify(1, buildNotification())
    }

    override fun onAccuracyChanged(s: Sensor?, a: Int) {}
    override fun onStartCommand(i: Intent?, f: Int, id: Int) = START_STICKY
    override fun onBind(i: Intent?): IBinder? = null

    override fun onDestroy() {
        getSystemService(SensorManager::class.java).unregisterListener(this)
        super.onDestroy()
    }
}
