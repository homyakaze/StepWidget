package com.example.steps

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

class StepWidget : AppWidgetProvider() {

    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) {
        refresh(c)
        startService(c)
    }

    override fun onEnabled(c: Context) = startService(c)

    private fun startService(c: Context) {
        try { c.startForegroundService(Intent(c, StepService::class.java)) } catch (_: Exception) {}
    }

    companion object {
        fun refresh(c: Context) {
            val m = AppWidgetManager.getInstance(c)
            val ids = m.getAppWidgetIds(ComponentName(c, StepWidget::class.java))
            if (ids.isEmpty()) return
            val v = RemoteViews(c.packageName, R.layout.widget)
            v.setTextViewText(R.id.count, "%,d".format(StepStore.today(c)).replace(',', ' '))
            m.updateAppWidget(ids, v)
        }
    }
}
