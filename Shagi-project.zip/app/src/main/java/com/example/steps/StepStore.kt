package com.example.steps

import android.content.Context
import java.time.LocalDate

// Хранит шаги за сегодня. Аппаратный счётчик считает с момента перезагрузки,
// поэтому запоминаем базу на начало дня и учитываем перезагрузки.
object StepStore {
    private fun prefs(c: Context) = c.getSharedPreferences("steps", Context.MODE_PRIVATE)

    fun onRaw(c: Context, raw: Long) {
        val p = prefs(c)
        val today = LocalDate.now().toString()
        var base = p.getLong("base", raw)
        var carry = p.getLong("carry", 0)
        val lastRaw = p.getLong("lastRaw", raw)
        if (p.getString("day", "") != today) {
            base = raw; carry = 0
        } else if (raw < lastRaw) { // телефон перезагружался
            carry += lastRaw - base
            base = 0
        }
        p.edit()
            .putString("day", today).putLong("base", base)
            .putLong("carry", carry).putLong("lastRaw", raw)
            .putLong("steps", carry + raw - base)
            .apply()
    }

    fun today(c: Context): Long {
        val p = prefs(c)
        return if (p.getString("day", "") == LocalDate.now().toString()) p.getLong("steps", 0) else 0
    }
}
